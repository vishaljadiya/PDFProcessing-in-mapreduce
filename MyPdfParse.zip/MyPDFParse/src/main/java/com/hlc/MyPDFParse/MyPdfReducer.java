package com.hlc.MyPDFParse;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyPdfReducer extends Reducer<Text,IntWritable,Text,IntWritable>{
	public MyPdfReducer() {
	System.out.println("inside reducer");
	}
	@Override
	protected void reduce(Text key, Iterable<IntWritable> value,
			Context context) throws IOException, InterruptedException {

		int sum=0;
		for (IntWritable values : value) {
			sum+=values.get();
		}
		System.out.println(key);
		context.write(key, new IntWritable(sum));
	
	}

}
