package com.hlc.MyPDFParse;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

public class MyPDFDriver {

	private static final String INPUT_DIR = "hdfs://localhost:9000/input_data";
	private static final String OUTPUT_DIR = "hdfs://localhost:9000/output_data";

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {


		Path input_dir = new Path(INPUT_DIR);
		Path output_dir = new Path(OUTPUT_DIR);

		MyIOUtils.uploadInputFile(INPUT_DIR);// Our class to upload the data.

		
		Configuration conf=new Configuration();
		GenericOptionsParser parser=new GenericOptionsParser(conf,args);
		args=parser.getRemainingArgs();
		Job job = Job.getInstance(conf, "myPDFWordCount");
		job.setJarByClass(MyPDFDriver.class);
		job.setMapperClass(MyPDFMapper.class);
		job.setReducerClass(MyPdfReducer.class);
		
		output_dir.getFileSystem(job.getConfiguration()).delete(output_dir, true);

		FileInputFormat.addInputPath(job, input_dir);
		FileOutputFormat.setOutputPath(job, output_dir);

		job.setInputFormatClass(MyPDFInputFormate.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		
		boolean flag = job.waitForCompletion(true);// returns true for normal
		// execution
		if (flag) {
			MyIOUtils.readOutputFile(OUTPUT_DIR);
		}


		

		
		
		
		
		}

}
