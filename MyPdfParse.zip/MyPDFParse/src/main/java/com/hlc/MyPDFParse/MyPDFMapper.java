package com.hlc.MyPDFParse;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyPDFMapper extends Mapper<LongWritable, Text, Text, IntWritable>{

	@Override
	protected void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
	
	String line=value.toString();
	String[]Datas=line.split(",");
	
		context.write(new Text( Datas[1]), new IntWritable(1));
	
//	System.out.println(line);
	}
	

}
